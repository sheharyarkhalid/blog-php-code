<?php 

ini_set('display_errors',1);
error_reporting(E_ALL);
include "../includes/db.php";
if(isset($_GET['action'])){
  if($_GET['action']=="art_delete"){
    $art_id=$_GET['id'];
    $ret = array(
      "success" => false
    );
    $del_art="DELETE FROM `articles` WHERE article_id='$art_id' "; 
    // $run_del_query=mysqli_query($db_conn,$del_art );
    if (mysqli_query($db_conn,$del_art )){
        $ret['success'] = true;
    } 
    echo json_encode($ret, true);
  }

  elseif($_GET['action']=="update_art_status"){
    $art_id=$_GET['id'];
    $status_value = $_GET['status_value'];
  
  
  $update_status="UPDATE `articles` SET `status`= '$status_value' WHERE article_id='$art_id' ";
// echo $update_status;
   
   if (mysqli_query($db_conn,$update_status )){
    echo json_encode(array("success"=> true), true);
    } else {
      echo json_encode(array("success"=> false), true);
    }


  
  }


 


}

function add_category($db_conn,$data){

  //  echo $data;
    $name = $data['cat_name'];
     $date=date("Y/m/d");
    $status='active';
   //print_r($name);
   $add_cat= "INSERT INTO `category` (`cat_title`, `date`, `status`) values ('$name','$date','$status')";
    $run_add_query=mysqli_query($db_conn,$add_cat);

 // $run_add_query ? true : false;
  
    return $run_add_query;
}
 

function get_category($db_conn){

$get_cat="SELECT * from `category`"; 

$run_get_query=$db_conn->query($get_cat);
// $ret[] ='';
// while($data = $run_get_query->fetch_assoc()){
//     $ret[] = $data;
// } 
$res = $run_get_query -> fetch_all(MYSQLI_ASSOC);

 return $res;
}


function update_category($db_conn,$data){
// echo "<pre>";
//  print_r($data);   

$name=$data['cat_name'];
$id=$data['cat_id'];

$update_cat_query="UPDATE `category` set `cat_title`='$name' WHERE `cat_id`='$id' ";
$update_query=$db_conn->query($update_cat_query);

return $update_query;

}

function delete_category($db_conn,$data){

    $id=$data['cat_id'];
    $delete_cat_query="DELETE FROM category WHERE cat_id ='$id' ";
    $delete_query=$db_conn->query($delete_cat_query);
    return $delete_query;
}

function create_slug($slug_text){
    $art_slug = preg_replace("/[\W_]+/", " ", $slug_text);
    $art_slug = preg_replace("/\s+|-+/", "-", $art_slug);
    $art_slug = preg_replace("/^\-/", " ", $art_slug);
    $art_slug = preg_replace("/^\-|\-$/", "", $art_slug);
   return $art_slug;
}

function add_articles($db_conn,$data,$files){
  // print_r($data);
   
   $ar_main_image=$files['main_image'];
   $ar_title=$data['article_name'];
   
   $art_slug= create_slug($ar_title);
     
  // echo $art_slug;

   $ar_cat=$data['category'];
   $ar_tag=$data['tags'];
  
   $ar_editor_content=$data['editor_content'];
 // $ar_editor_content=$db_conn->real_escape_string($ar_editor_content);

   $desc = array("html"=> "");
   $desc['html'] = urlencode($ar_editor_content);
   $final_desc = json_encode($desc);
   //echo $final_desc;
  // die();

//   $teste=json_decode($final_desc);
    
//   echo urldecode($teste->html);
//   $tets= urldecode($teste);
// print_r($tets);

   $date=date("Y/m/d");
   $status=true;
  // $ar_tag=explode(" ",$ar_tag);
   $ar_tag=json_encode($ar_tag,true);
   //print_r($ar_tag);

   $get_art="SELECT * from `articles` WHERE article_slug='$art_slug' "; 
   $run_check_ar=mysqli_query($db_conn,$get_art); 
// echo $run_check_ar;
 //echo mysqli_num_rows($run_check_ar);
if(mysqli_num_rows($run_check_ar)>0){
$responce='300';
  return $responce;

}
else{

// Check if a file was uploaded
if (isset($ar_main_image)) {
   $file = $ar_main_image;
   
   //ini_set("file_uploads", 1);

   // File details
   $fileName = $file['name'];
   $fileTmp = $file['tmp_name'];
   $fileSize = $file['size'];
   $fileError = $file['error'];

   // Get the file extension
   $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

   // Define allowed file extensions
   $allowedExtensions = array('jpg', 'jpeg', 'png','webp');

   // Check if the file extension is allowed
   if (in_array($fileExt, $allowedExtensions)) {

       // Check for file upload errors
       if ($fileError === 0) {
           // Generate a unique name for the file
           $newFileName = uniqid('', true) . '.' . $fileExt;

           // Define the upload directory
           $uploadDir = 'uploads/';
           //chmod($uploadDir,0777);
            $full_path=$uploadDir . $newFileName;
          //  echo $full_path;
           // Move the uploaded file to the desired location
           if (move_uploaded_file($fileTmp, $uploadDir . $newFileName)) {
           
              echo 'File uploaded successfully.';
            

               $add_ar= "INSERT INTO `articles`(`arr_main_img`, `article_title`, `article_category`, `article_tag`,`date`,`status`,`article_des`,`article_slug`) values ('$full_path','$ar_title','$ar_cat','$ar_tag','$date','$status','$final_desc','$art_slug')";

               $run_add_ar=mysqli_query($db_conn,$add_ar); 
              return $run_add_ar;
               //echo $run_add_ar;
             //  $conn = null; // Close the database connection
           } else {
               echo 'Error uploading file.';
           }
       } else {
           echo 'Error: ' . $fileError;
       }
   } else {
       echo 'Invalid file extension. Only JPG, JPEG, and PNG files are allowed.';
   }
}

}

}


function get_articles($db_conn){

  $get_art="SELECT * from `articles`"; 
  
  $run_get_query=$db_conn->query($get_art);
  // $ret[] ='';
  // while($data = $run_get_query->fetch_assoc()){
  //     $ret[] = $data;
  // } 
  
  // $teste=json_decode($run_get_query);
      
  // echo urldecode($teste->html);
  // $tets= urldecode($teste);
  
  
  $res = $run_get_query -> fetch_all(MYSQLI_ASSOC);
  
   return $res;
  
  }

  function delete_article($db_conn,$data){

    $id=$data['art_id'];
    $delete_art_query="DELETE FROM articles WHERE id ='$id' ";
    $delete_query=$db_conn->query($delete_art_query);
    return $delete_query;
}

function get_specific_articles($db_conn,$art_id){

  $get_art="SELECT * from `articles` WHERE  article_id='$art_id'"; 
    $run_get_query=$db_conn->query($get_art);
    $res = $run_get_query -> fetch_all(MYSQLI_ASSOC);
    return $res[0];
   
  
  }

  function update_specific_articles($db_conn,$data,$files){
    // print_r($data);
     $update_article_id=$data['update_id'];
     $ar_main_image=$files['main_image'];
     $ar_title=$data['article_name'];
        
     $art_slug= create_slug($ar_title);
       
    // echo $art_slug;
  
     $ar_cat=$data['category'];
     $ar_tag=$data['tags'];
    
     $ar_editor_content=$data['editor_content'];
   // $ar_editor_content=$db_conn->real_escape_string($ar_editor_content);
  
     $desc = array("html"=> "");
     $desc['html'] = urlencode($ar_editor_content);
     $final_desc = json_encode($desc);
     //echo $final_desc;
    // die();
  
  //   $teste=json_decode($final_desc);
      
  //   echo urldecode($teste->html);
  //   $tets= urldecode($teste);
  // print_r($tets);
  
     $date=date("Y/m/d");
     $status=true;
    // $ar_tag=explode(" ",$ar_tag);
     $ar_tag=json_encode($ar_tag,true);
     //print_r($ar_tag);
  
     $get_art="SELECT * from `articles` WHERE article_slug='$art_slug' "; 
     $run_check_ar=mysqli_query($db_conn,$get_art); 
  // echo $run_check_ar;
   //echo mysqli_num_rows($run_check_ar);
  if(mysqli_num_rows($run_check_ar)>0){
  $responce='300';
    return $responce;
  
  }
  else{
  
  // Check if a file was uploaded
  if (isset($ar_main_image)) {
     $file = $ar_main_image;
     
     //ini_set("file_uploads", 1);
  
     // File details
     $fileName = $file['name'];
     $fileTmp = $file['tmp_name'];
     $fileSize = $file['size'];
     $fileError = $file['error'];
  
     // Get the file extension
     $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
  
     // Define allowed file extensions
     $allowedExtensions = array('jpg', 'jpeg', 'png','webp');
  
     // Check if the file extension is allowed
     if (in_array($fileExt, $allowedExtensions)) {
  
         // Check for file upload errors
         if ($fileError === 0) {
             // Generate a unique name for the file
             $newFileName = uniqid('', true) . '.' . $fileExt;
  
             // Define the upload directory
             $uploadDir = 'uploads/';
             //chmod($uploadDir,0777);
              $full_path=$uploadDir . $newFileName;
            //  echo $full_path;
             // Move the uploaded file to the desired location
             if (move_uploaded_file($fileTmp, $uploadDir . $newFileName)) {
             
                echo 'File uploaded successfully.';
              
  
                 $add_ar= "UPDATE `articles` SET `arr_main_img`='$full_path', `article_title`='$ar_title', `article_category`='$ar_cat', `article_tag`='$ar_tag',`date`='$date',`status`='$status',`article_des`='$final_desc',`article_slug`='$art_slug' WHERE article_id=$update_article_id";
  
                 $run_add_ar=mysqli_query($db_conn,$add_ar); 

                //  if(mysqli_query($db_conn,$add_ar)){
                //   echo 'best';
                // }
               
               // echo  $add_ar;
               
                //die();
               return $run_add_ar;
               //  $conn = null; // Close the database connection
             } else {
                 echo 'Error uploading file.';
             }
         } else {
             echo 'Error: ' . $fileError;
         }
     } else {
         echo 'Invalid file extension. Only JPG, JPEG, and PNG files are allowed.';
     }
  }
  
  }
  
  }


// function update_art($db_conn,$data){

// }
 ?>