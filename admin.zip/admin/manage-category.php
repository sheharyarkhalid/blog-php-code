<!DOCTYPE html>
<html lang="en">

<head>
  <?php
  include('includes/head.php');
  ?>
</head>

<?php
include('includes/db.php');
include('php-files/function.php');

if (isset($_GET['add_category'])) {

  $responce = add_category($db_conn, $_GET);
  if ($responce == '1' || $responce == 'true') {

?>
    <script>
      $(document).ready(function() {
        $('.category_page_alert').addClass('show');
        $('.category_page_alert p').text('Category added !');
        setTimeout(function() {
          $('.category_page_alert').removeClass('show');
        }, 4000);

      });
    </script>

  <?php } else {
  }

  //  echo $responce;
}

if (isset($_POST['update_category'])) {

  $responce = update_category($db_conn, $_POST);

  if ($responce == '1' || $responce == 'true') {

  ?>
    <script>
      $(document).ready(function() {
        $('.category_page_alert').addClass('show');
        $('.category_page_alert p').text('Category Updated !');
        setTimeout(function() {
          $('.category_page_alert').removeClass('show');
        }, 4000);

      });
    </script>

  <?php } else {
  }
}

if (isset($_POST['delete_category'])) {

  $responce = delete_category($db_conn, $_POST);


  if ($responce == '1' || $responce == 'true') {

  ?>
    <script>
      $(document).ready(function() {
        $('.category_page_alert').addClass('show');
        $('.category_page_alert p').text('Category Deleted !');
        setTimeout(function() {
          $('.category_page_alert').removeClass('show');
        }, 4000);

      });
    </script>

<?php } else {
  }
}

?>



<body>

  <div class="alert alert-success alert-dismissible fade category_page_alert" role="alert">
    <p></p>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>

  <?php
  include('includes/sidebar.php');
  ?>

  <div class="content-section">
    <?php
    include('includes/header.php');
    ?>

    <div class="content-section-main">
      <div class="content-container">
        <div class="responsive_content_manage">

          <div class="pagination-list">
            <h5> Manage Category</h5>
            <button type="button" class="" data-toggle="modal" data-target="#add_category_modal">
              Add Category
            </button>
          </div>


          <table id="record_data_tabel" class="table table-striped table-bordered" style="width:100%">
            <thead>
              <tr>

                <th>Category</th>
                <th>Date</th>
                <th>status</th>
                <th>Edit</th>
                <th>Delete</th>

              </tr>
            </thead>
            <tbody>
              <?php
              $get_responce = get_category($db_conn);


              foreach ($get_responce as $cat) {
                //  echo '<pre>';
                //  print_r($cat);
                // echo '</pre>';
              ?>

                <tr>

                  <td contenteditable="true"><?= $cat['cat_title'] ?></td>
                  <td><?= $cat['date'] ?></td>
                  <td><?= $cat['status'] ?></td>
                  <td>
                    <button type="button" class="change_category_btn" data-toggle="modal" data-target="#edit_category_modal<?= $cat['cat_id'] ?>">
                      <i class='fa fa-edit'></i>
                    </button>

                  </td>
                  <td>
                    <button type="button" class="change_category_btn" data-toggle="modal" data-target="#delete_category_modal<?= $cat['cat_id'] ?>">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  </td>
                </tr>
                <!-- Edit category_modal -->
                <div class="add_category_modal modal fade" id="edit_category_modal<?= $cat['cat_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="edit_category_modal<?= $cat['cat_id'] ?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-slideout" role="document">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Update category</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form method="POST" novalidate="novalidate">
                        <div class="form_design_one_content_box">



                          <div class="form_design_one_field_box">
                            <div class="form_design_one_single_field_box">
                              <span>Title</span>
                              <input type="text" placeholder="Enter category name" value="<?= $cat['cat_title'] ?>" name="cat_name" id="cat_name" required />

                            </div>
                            <label class="error" generated="true" for="cat_name"></label>
                          </div>
                          <input type="hidden" value="<?= $cat['cat_id'] ?>" name="cat_id">

                          <div class="form_design_one_submit_btn">
                            <button id="add_category" class="add_category" name="update_category" type="submit">
                              update category
                            </button>
                          </div>
                        </div>
                      </form>

                    </div>
                  </div>
                </div>

                <!-- Delete category_modal -->

                <div class="add_category_modal modal fade" id="delete_category_modal<?= $cat['cat_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="delete_category_modal<?= $cat['cat_id'] ?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-slideout" role="document">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Delete Category</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form method="POST" novalidate="novalidate">
                        <div class="form_design_one_content_box">
                          <div class="form_design_one_field_box">
                            <div class="form_design_three_single_field_box">
                              <span>Are you sure you want to delete ?</span>
                            </div>

                          </div>
                          <input type="hidden" value="<?= $cat['cat_id'] ?>" name="cat_id">
                          <div class="form_design_one_submit_btn">
                            <button name="delete_category" type="submit">
                              Delete
                            </button>
                          </div>
                        </div>
                      </form>

                    </div>
                  </div>
                </div>

              <?php }

              ?>



            </tbody>

          </table>



          <!-- add_category_modal -->

          <div class="add_category_modal modal fade" id="add_category_modal" tabindex="-1" role="dialog" aria-labelledby="add_category_modal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-slideout" role="document">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Task</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="get" novalidate="novalidate">
                  <div class="form_design_one_content_box">



                    <div class="form_design_one_field_box">
                      <div class="form_design_one_single_field_box">
                        <span>Title</span>
                        <input type="text" placeholder="Enter category name" name="cat_name" id="cat_name" required />

                      </div>
                      <label class="error" generated="true" for="cat_name"></label>
                    </div>
                    <div class="form_design_one_submit_btn">
                      <button id="add_category" class="add_category" name="add_category" type="submit">
                        Add category
                      </button>
                    </div>
                  </div>
                </form>

              </div>
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>

</body>






</html>