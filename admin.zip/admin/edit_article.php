<!DOCTYPE html>
<html lang="en">

<head>
  <?php include('includes/head.php'); ?>
</head>

<body>
  <?php
  include('includes/db.php');
  include('php-files/function.php');


  if(isset($_GET['art_id'])){
    $art_id=$_GET['art_id'];
    $responce=get_specific_articles($db_conn,$art_id);
    //echo "<pre>";
   //print_r($responce);


   $ar_tag = ltrim($responce['article_tag'], $responce['article_tag'][0]);
   $ar_tag=substr($ar_tag, 0, -1);
  
     $tags=json_decode($ar_tag,true);

      $result_tag=array();
     foreach($tags as $tagvalue){
      $result_tag[]=$tagvalue['value'];
     }
     $resultString = implode(", ", $result_tag);
     //echo $resultString;
 
   // $final_date=date("F j, Y", strtotime($res_single_art['date']));

    $img_value=$responce['arr_main_img'];
    $art_desc =  json_decode($responce['article_des'], true);
    $final_art_des= urldecode($art_desc['html']);
    
   // echo  $final_art_des ;
  }


  if (isset($_POST['update_article'])) {

    $responce = update_specific_articles($db_conn, $_POST, $_FILES);

    echo  $responce;

    if ($responce == '1' || $responce == 'true') {


      $responce=get_specific_articles($db_conn,$art_id);
      //echo "<pre>";
     //print_r($responce);
  
  
     $ar_tag = ltrim($responce['article_tag'], $responce['article_tag'][0]);
     $ar_tag=substr($ar_tag, 0, -1);
    
       $tags=json_decode($ar_tag,true);
  
        $result_tag=array();
       foreach($tags as $tagvalue){
        $result_tag[]=$tagvalue['value'];
       }
       $resultString = implode(", ", $result_tag);
       //echo $resultString;
   
     // $final_date=date("F j, Y", strtotime($res_single_art['date']));
  
      $img_value=$responce['arr_main_img'];
      $art_desc =  json_decode($responce['article_des'], true);
      $final_art_des= urldecode($art_desc['html']);
      


  ?>
      <script>
        $(document).ready(function() {
          $('.category_page_alert').addClass('show');
          $('.category_page_alert p').text('Article updated !');
          setTimeout(function() {
            $('.category_page_alert').removeClass('show');
          }, 4000);

        });
      </script>

    <?php

    } elseif ($responce == '300') {

      $responce=get_specific_articles($db_conn,$art_id);
      //echo "<pre>";
     //print_r($responce);
  
  
     $ar_tag = ltrim($responce['article_tag'], $responce['article_tag'][0]);
     $ar_tag=substr($ar_tag, 0, -1);
    
       $tags=json_decode($ar_tag,true);
  
        $result_tag=array();
       foreach($tags as $tagvalue){
        $result_tag[]=$tagvalue['value'];
       }
       $resultString = implode(", ", $result_tag);
       //echo $resultString;
   
     // $final_date=date("F j, Y", strtotime($res_single_art['date']));
  
      $img_value=$responce['arr_main_img'];
      $art_desc =  json_decode($responce['article_des'], true);
      $final_art_des= urldecode($art_desc['html']);
      



    ?>
      <script>
        $(document).ready(function() {
          $('.category_page_alert').addClass('show');
          $('.category_page_alert p').text('Same article already added !');
          setTimeout(function() {
            $('.category_page_alert').removeClass('show');
          }, 4000);

        });
      </script>

  <?php
    }
  }


  ?>

  <?php
  include('includes/sidebar.php');
  ?>

  <div class="alert alert-success alert-dismissible fade category_page_alert" role="alert">
    <p></p>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>


  <div class="content-section">
    <?php
    include('includes/header.php');
    ?>

    <div class="content-section-main">
      <div class="content-container">
        <div class="responsive_content_manage">
          <div class="pagination-list">
            <h5>Update Articals</h5>
          
          </div>


          <form method="POST" enctype="multipart/form-data">
            <div class="form_design_one_content_box">
              <div class="article_image_preview"> <img id="preview" src="<?php echo $img_value ?>" alt="Image Preview" width="200" height="200"></div>
              <div class="form_design_one_field_box_main">
                <div class="form_design_one_field_box">
                  <div class="form_design_one_single_field_box">
                    <span>Article Main image</span>
                    <input type="file" name="main_image" id="article_main_img" value="<?php echo $img_value ?>" onchange="previewImage(event)">
                  </div>
                  <label class="error" generated="true" for="article_main_img"></label>
                </div>

                <div class="form_design_one_field_box">
                  <div class="form_design_one_single_field_box">
                    <span>Article Name</span>
                    <input type="text" placeholder="Enter Article Name" name="article_name" id="article_name" value="<?php echo $responce['article_title']; ?>" required />

                  </div>
                  <label class="error" generated="true" for="article_name"></label>
                </div>
              </div>
              <div class="form_design_one_field_box_main">
                <div class="form_design_one_field_box">
                  <div class="form_design_one_single_field_box">
                    <span>Select Category</span>
                    <select name="category" id="category" required>
                      <option selected value="<?php echo $responce['article_category'];?>" ><?php echo $responce['article_category'];?></option>
                      <?php
                      $responce = get_category($db_conn);

                      foreach ($responce as $cat) {
                        echo '<pre>';
                        print_r($cat);
                        echo '</pre>';
                      ?>
                        <option value="<?= $cat['cat_title'] ?>"><?= $cat['cat_title'] ?></option>
                      <?php }
                      ?>

                    </select>
                  </div>
                  <label class="error" generated="true" for="category"></label>
                </div>

                <div class="form_design_one_tag_field_box">
                  <div class="form_design_one_single_tag_field">
                    <small>Tags</small>
                    <input type="text" name="tags" id="tagInput" value="<?php echo $resultString; ?>">
                  </div>
                  <label class="error" generated="true" for="tags"></label>
                </div>
              </div>

              <div class="form_design_one_tag_field_box">
                <div class="form_design_one_single_tag_field">

                  <textarea name="editor_content" id="tinymce_editor"><?php echo  $final_art_des; ?></textarea>
                </div>

              </div>
                <input type="hidden" value="<?php echo $art_id; ?>" name="update_id">
              <div class="form_design_one_submit_btn">
                <button id="update_article" name="update_article" type="submit">
                Update Article
                </button>
              </div>
            </div>
          </form>


        </div>
      </div>
    </div>


    <script type="text/javascript" src="tinymce/tinymce.min.js"></script>

    <script>
      tinymce.init({
        selector: 'textarea#tinymce_editor', //Change this value according to your HTML

        plugins: "advlist autolink lists link image charmap print preview hr anchor pagebreak searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking save table contextmenu directionality emoticons template paste textcolor colorpicker textpattern imagetools",
        cleanup: false,
        remove_linebreaks: true,
        convert_newlines_to_brs: false,
        inline_styles: false,
        entity_encoding: 'raw',
        entities: '160,nbsp,38,amp,60,lt,62,gt',
        verify_html: false,
        forced_root_block: false,
        preformatted: true,
        schema: 'html5',
        valid_children: '+a[div],+a[span],+body[style]',
        extended_valid_elements: 'style',
        custom_elements: 'style',

        advcode_inline: true,
        toolbar: "undo redo print spellcheckdialog formatpainter | blocks fontfamily fontsize | bold italic underline forecolor backcolor | link image | alignleft aligncenter alignright alignjustify | code",

        image_title: true,
        /* enable automatic uploads of images represented by blob or data URIs*/
        automatic_uploads: true,
        /*
          URL of our upload handler (for more details check: https://www.tiny.cloud/docs/configure/file-image-upload/#images_upload_url)
          images_upload_url: 'postAcceptor.php',
          here we add custom filepicker only to Image dialog
        */
        file_picker_types: 'image',
        /* and here's our custom image picker*/
        file_picker_callback: function(cb, value, meta) {
          var input = document.createElement('input');
          input.setAttribute('type', 'file');
          input.setAttribute('accept', 'image/*');

          /*
            Note: In modern browsers input[type="file"] is functional without
            even adding it to the DOM, but that might not be the case in some older
            or quirky browsers like IE, so you might want to add it to the DOM
            just in case, and visually hide it. And do not forget do remove it
            once you do not need it anymore.
          */

          input.onchange = function() {
            var file = this.files[0];

            var reader = new FileReader();
            reader.onload = function() {
              /*
                Note: Now we need to register the blob in TinyMCEs image blob
                registry. In the next release this part hopefully won't be
                necessary, as we are looking to handle it internally.
              */
              var id = 'blobid' + (new Date()).getTime();
              var blobCache = tinymce.activeEditor.editorUpload.blobCache;
              var base64 = reader.result.split(',')[1];
              var blobInfo = blobCache.create(id, file, base64);
              blobCache.add(blobInfo);

              /* call the callback and populate the Title field with the file name */
              cb(blobInfo.blobUri(), {
                title: file.name
              });
            };
            reader.readAsDataURL(file);
          };

          input.click();
        },

      });
    </script>

</body>





</html>