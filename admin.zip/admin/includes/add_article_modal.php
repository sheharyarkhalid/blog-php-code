<style>
  .art_modal_sidebar {
    top: 0px;
    right: 0px;
    width: 800px;
    height: 100vh;
    overflow-y: auto;
    scrollbar-width: thin;
    background-color: var(--bg-color-two);
    display: flex;
    flex-direction: column;
    position: fixed;
    transform: translateX(100%);
    transition: 0.5s ease-in-out;
    z-index: 99;
    box-shadow: 0 3px 10px rgb(0 0 0 / 0.2);
   padding: 40px 30px 30px 30px;
  }

  .art_modal_sidebar.active {
    transform: translateX(0%);
    transition: 0.5s ease-in-out;
  }

  .art_res_close_btn i {
    color: #000;
    font-size: 14px;
  }

  .art_res_close_btn {
    cursor: pointer;
  }

  .art_modal_header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    border-bottom: 1px solid #e9ecef;
    margin-bottom: 20px;
    padding-bottom: 15px;
  }
</style>
<div class="art_modal_sidebar">

  <div class="" role="document">
    <div class="art_modal_header">
      <h5 class="modal-title" id="exampleModalLabel">Add Article</h5>
      <div class="art_res_close_btn art_modal_btn"><i class="fal fa-times"></i></div>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <div class="form_design_one_content_box">
        <div class="article_image_preview"> <img id="preview" src="https://static.tossdown.com/images/2760b153-df8d-4fce-b9ef-cdd1d1817fac.png" alt="Image Preview" width="200" height="200"></div>
        <div class="form_design_one_field_box_main">
          <div class="form_design_one_field_box">
            <div class="form_design_one_single_field_box">
              <span>Article Main image</span>
              <input type="file" name="main_image" id="article_main_img" onchange="previewImage(event)" required>
            </div>
            <label class="error" generated="true" for="article_main_img"></label>
          </div>

          <div class="form_design_one_field_box">
            <div class="form_design_one_single_field_box">
              <span>Article Name</span>
              <input type="text" placeholder="Enter Article Name" name="article_name" id="article_name" required />

            </div>
            <label class="error" generated="true" for="article_name"></label>
          </div>
        </div>
        <div class="form_design_one_field_box_main">
          <div class="form_design_one_field_box">
            <div class="form_design_one_single_field_box">
              <span>Select Category</span>
              <select name="category" id="category" required>
                <?php
                $responce = get_category($db_conn);

                foreach ($responce as $cat) {
                  echo '<pre>';
                  print_r($cat);
                  echo '</pre>';
                ?>
                  <option value="<?= $cat['cat_title'] ?>"><?= $cat['cat_title'] ?></option>
                <?php }
                ?>

              </select>
            </div>
            <label class="error" generated="true" for="category"></label>
          </div>

          <div class="form_design_one_tag_field_box">
            <div class="form_design_one_single_tag_field">
              <small>Tags</small>
              <input type="text" name="tags" id="tagInput" value="">
            </div>
            <label class="error" generated="true" for="tags"></label>
          </div>
        </div>

        <div class="form_design_one_tag_field_box">
          <div class="form_design_one_single_tag_field">

            <textarea name="editor_content" id="tinymce_editor"></textarea>
          </div>

        </div>

        <div class="form_design_one_submit_btn">
          <button id="add_article" name="add_article" type="submit">
            Add Article
          </button>
        </div>
      </div>
    </form>
  </div>
</div>