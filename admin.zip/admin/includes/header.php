<section class="dashboard-header">
      <div class="header-container">
        <div class="web_header_main">
          <div class="web_header_0">
            <ul class="web_header_0_list_0">
              <li class="li_0 web_header_logo">
                <a class="header-hamburger-btn">
                  <i class="ri-menu-fill hamburger_img"></i>
                </a>
              </li>
              <ul class="web_header_0_list_1">
                <li class="li_0"><a to="/"> Task Manager</a> </li>
              </ul>
            </ul>
            <ul class="web_header_0_list_2">
              <li class="li_0"> 
                <div id="user_detail">
                  <i class="fal fa-user" style="font-size:16px;color: #4A4A4A;"></i>
                  <div id="detail_box">
                    <a href="setting.html">Settings</a>
                    <a href="login.html">Logout</a>
                  </div>
              </div>
                        

              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
