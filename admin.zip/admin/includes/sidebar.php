<div class="dashboard-sidebar">
    <div class="res_close_btn hamburger_img"><i class="fal fa-times"></i></div>
    <div class="dashboard-sidebar-logo">
      <h2> Manage Blog</h2>
    </div>
    <div class="sidebar-menu-list">




      <div class="sidebar-menu-list-box">

        <div class="single-sidebar-menu-list open">
          <span>Manage Blog</span>
        </div>
        <div class="single-menu-data-box">

          <div class="single-menu-data-list">
            <div class="single-menu-data-list-tag">
              <a href="index.php" >Home</a>

            </div>

          </div>

          <div class="single-menu-data-list">
            <div class="single-menu-data-list-tag">
              <a href="manage-category.php">Manage Category</a>

            </div>

          </div>
          <div class="single-menu-data-list">
            <div class="single-menu-data-list-tag">
              <a href="Calendar.html" >Calendar</a>

            </div>

          </div>

          <div class="single-menu-data-list">
            <div class="single-menu-data-list-tag">
              <a href="setting.html">Setting</a>

            </div>

          </div>


        </div>
      </div>


    </div>


  </div>