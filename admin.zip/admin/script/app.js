$(document).ready(function() {
    var spinner = $('#loader');

    $('#record_data_tabel').DataTable({
    lengthMenu: [
        [10, 10, 50, -1],
        [10, 10, 50, 200 , 'All'],
    ],
});

oTable = $('#record_data_tabel').DataTable();  
$('#custom_datatable_search_field').keyup(function(){
      oTable.search($(this).val()).draw() ;
});



     jQuery(function ($) {
     var $question = $(".single-menu-data-list");
    
     $question.click(function () {

       // Hide all answers
       $answer.slideUp();
       // Check if this answer is already open
       if ($(this).hasClass("open")) {

         // If already open, remove 'open' class and hide answer
         $(this).removeClass("open").next($answer).slideUp();
        // If it is not open...
      } else {
        // Remove 'open' class from all other questions
        $question.removeClass("open");
        // Open this answer and add 'open' class
        $(this).addClass("open").next($answer).slideDown();
       }
     });
 });

  $(".hamburger_img").click(function () {
    $(".dashboard-sidebar").toggleClass("active");
    $(".content-section").toggleClass("active");
  });

  // multi tag input script start

  var taginput = document.getElementById('tagInput');
  var tagify = new Tagify(taginput);

  tagify.on('add', function(e) {
    var tags = tagify.value.map(tagData => tagData.value);
   // console.log(tags);
    taginput.value = tags.join(',');
   // console.log(taginput.value);
    $('#tagInput').attr("value", taginput.value);
  });

  tagify.on('remove', function(e) {
    var tags = tagify.value.map(tagData => tagData.value);
    taginput.value = tags.join(',');
  });
 // multi tag input script end

});

function previewImage(event) {
  var input = event.target;
  var reader = new FileReader();
  reader.onload = function () {
      var imgElement = document.getElementById('preview');
      imgElement.setAttribute("src", reader.result);
  }
  reader.readAsDataURL(input.files[0]);
}